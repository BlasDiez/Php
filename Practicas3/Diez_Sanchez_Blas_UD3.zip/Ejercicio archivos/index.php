<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Hemeroteca</title>
</head>
<body>
    <h1>Ejercicio P3B - Hemeroteca</h1>
    <a href="subir.php">Subir un archivo</a>
    <br><br>
    <a href="listar.php">Ver archivos subidos</a>
</body>
</html>
